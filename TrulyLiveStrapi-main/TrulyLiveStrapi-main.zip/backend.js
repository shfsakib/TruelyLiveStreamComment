export const baseUrl = 'https://trulylive.herokuapp.com/api'
export const cloudName = 'dvp71mrzo'
